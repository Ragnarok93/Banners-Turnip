DXVK diagnostic logs
source_directory=/data/user/0/app.gamenative/files/imagefs/tmp/dxvk_logs
file_count=0
capture_window_note=DXVK loggers initialize when the game process starts, so startup messages cannot be toggled on from the in-game Quick Menu. These files cover the process lifetime up to export, while the capture metadata/frame timestamps describe the selected in-game window.
status=no DXVK .log files were found
check=Confirm the game uses DXVK and inspect the app/container startup log for log-directory write errors.
